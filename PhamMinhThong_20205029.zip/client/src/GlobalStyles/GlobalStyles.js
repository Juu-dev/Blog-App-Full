import "./GlobalStyles.scss";

export default function GlobalStyles({ children }) {
    return children;
}
